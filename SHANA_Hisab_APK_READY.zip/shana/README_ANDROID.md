# SHANA Hisab — APK-ready Android project

This project is ready to open in Android Studio and build as an installable APK.

## App
- Name: SHANA Hisab
- Application ID: `com.shana.hisab`
- Version: `1.1.0` (versionCode 2)
- Minimum Android: 6.0 / API 23
- Target SDK: 35
- Portrait phone layout
- Offline-first: the web UI is bundled inside the APK
- LocalStorage data is kept on the device

## Build APK in Android Studio
1. Open the project folder in Android Studio.
2. Let Gradle sync finish.
3. Select **Build → Generate App Bundles or APKs → Generate APKs**.
4. The debug APK will normally be under `app/build/outputs/apk/debug/`.
5. Install that APK on the Android phone.

For a signed release APK, use **Build → Generate Signed App Bundle / APK**.

## Important
This project intentionally does not include a signing key. Android Studio can create a debug APK immediately, while a release APK should be signed with a keystore owned by the app owner.
