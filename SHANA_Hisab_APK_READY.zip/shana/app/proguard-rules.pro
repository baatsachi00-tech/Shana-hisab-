# SHANA Hisab: no custom shrinking rules required.
