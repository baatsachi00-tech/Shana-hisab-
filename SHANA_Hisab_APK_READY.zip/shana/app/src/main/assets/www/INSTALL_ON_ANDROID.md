# SHANA Hisab — Android Install Guide

1. Upload this folder to an HTTPS web host.
2. Open the HTTPS URL in Chrome on Android.
3. Wait for the app to load once.
4. Use Chrome menu → Install app (or Add to Home screen when offered).
5. The installed app opens in standalone mode.

Important: a ZIP/file:// copy cannot satisfy normal PWA installation requirements.
This package is PWA-ready, but it must be served over HTTPS for normal Chrome installation.

Current data storage: local device storage. Cloud login/sync is not included yet.
